package autovivification::TestRequired4::c0;
my $x;
my $y = $x->{foo};
1;
