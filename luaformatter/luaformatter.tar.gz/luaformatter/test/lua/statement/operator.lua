assert(2.0^-2 == 1/4 and -2^- -2 == - - -4)
x = x&y or not z or #z;
(#{})[0]:func()[1]:func().v.w()