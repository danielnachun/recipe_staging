local x<close> = {}
local y<const> = {}
local x<close>, y<const>, z<anything> = 1, 2, 3
