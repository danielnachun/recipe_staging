q = {
    w = { -- empty
    },

    -- keep custom blank line
    e = { --[[comment]] },
    r = {
        -- empty
    },
    -- comment
    nothing = {}
    -- comment
}
-- last comment
