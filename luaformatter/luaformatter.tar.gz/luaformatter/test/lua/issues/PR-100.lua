local var = function_call( alpha, beta, charlie, delta, echo, gamma, foxtrot, golf, hotel, india, juliet, kilo)
