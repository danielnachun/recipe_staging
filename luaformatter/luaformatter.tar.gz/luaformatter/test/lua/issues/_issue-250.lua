globals.regexIgnorePaths = {
    "^[a-z]:\\\\users\\\\.*\\\\appdata\\\\",
    "^[a-z]:\\\\users\\\\.*\\\\downloads\\\\",
}