if aaaaaaa == 1 and bbbbb == 1 and bbbbb == 1 and bbbbb == 1 and bbbbb == 1 and
    b == -1 and bbbbb == 1 and bbbbb == 1 and bbbbb == 1 and bbbbb == 1 and
    bbbbb == 1 and bbbbb == 1 then print(1) end
