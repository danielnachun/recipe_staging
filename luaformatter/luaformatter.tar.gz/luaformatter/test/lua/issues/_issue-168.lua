do
	do
		do
			foobar()
			function_with_oh_so_very_long_name("argument", "another argument that is quite long",
			                                   "yet another long string argument")
			barfoo()
		end
	end
end
