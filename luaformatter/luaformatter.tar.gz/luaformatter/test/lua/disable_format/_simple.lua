-- LuaFormatter off
local x = xx:www()
            :a()
            :b():c()
            :d()
-- LuaFormatter on
local x = xx:www():a():b():c():d()
-- LuaFormatter off
local x = xx:www()
            :a()
            :b():c()
            :d()
-- LuaFormatter on
