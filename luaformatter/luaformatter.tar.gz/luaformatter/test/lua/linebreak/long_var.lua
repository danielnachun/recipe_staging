xxxxxxxxxxxxxxxxxx:xxxxxxxxxxxxxxxxxxx(
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww"
)
xxxxxxxxxxxxxxxxxx:xxxxxxxxxxxxxxxxxxxxxx(
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww",
    args .. "wwwwwwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwww" .. "wwwwwwwwwwwwwwww"
)

local xxxxxxxxxxxxxxxxxx,xxxxxxxxxxxxxxxxxx,xxxxxxxxxxxxxxxxxx,xxxxxxxxxxxxxxxxxx = 1,2,3,4

function a()
    function a()
        function a()
            function a()
                local xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx = 1
            end
        end
    end
end