function x()
    local ok, err =
        self.var:method(ppppppppppppppppppppppp, pppppppppppppppp, pppppppppppppppp)
end

if true then
    if true then
        ngx
            .log(ngx_ERR,
                 'test string' .. "failed to create timer: " .. (err or 'nil'))
    end
end