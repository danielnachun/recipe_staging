function long_method(aaa, bbbb, ccccc, ddddd, eeeeee, fffffff, gggggggg,
                     hhhhhhhhh, iiiiiiiiii, jjjjjjjjjj, kkkkkkkkkkkk,
                     lllllllllllllllll)
    -- do nothing
end

-- wrap first parameter
function very_very_very_very_very_very_very_very_very_very_long_method(
    aaaaaaaaaaaaaa, bbbb, ccccc, ddddd, eeeeee, fffffff, gggggggg, hhhhhhhhh,
    iiiiiiiiii, jjjjjjjjjj, kkkkkkkkkkkk, lllllllllllllllll)
    -- do nothing
end

function x(aaaaaaa, aaaaaaaaa, aaaaaaaaaaaa, aaaaaaaaaaaa, aaaaaaaaaaaaaaaaaaaa)
    print(1)
    print(2)
end

function x(aaaaaaa, aaaaaaaaa, aaaaaaaaaaaa, aaaaaaaaaaaa, aaaaaaaaaaaaaaaaaaaaa)
    print(1)
    print(2)
end

function x(aaaaaaa, aaaaaaaaa, aaaaaaaaaaaa, aaaaaaaaaaaa,
           aaaaaaaaaaaaaaaaaaaaaa)
    print(1)
    print(2)
end
