local x = aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa +
              aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa +
              aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa +
              aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa + aaaaaaa +
              aaaaaaa + aaaaaaa + aaaaaaa

x = wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww + wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

x = wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww + wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

x = wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww +
        wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

x = wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww +
        wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
