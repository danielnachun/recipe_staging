# Setup the webpage
1. Place your svg files in the directory "svgs".
2. Run build.py. This will create "svg_paths.json" so that the webpage script knows which svgs to include.

# Run the webpage
1. You can use the command "python3 -m http.server" to run a server. Once the server is running, connect to localhost using the respective port.